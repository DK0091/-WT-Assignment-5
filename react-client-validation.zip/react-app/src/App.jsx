import { useMemo, useState } from 'react';
import { TRACKS, validateAll, passwordStrength, calcAge } from './validators.js';

const INITIAL = { name: '', email: '', phone: '', dob: '', gender: '', track: '', password: '', confirm: '', bio: '', terms: false };
const STRENGTH = ['', 'Weak', 'Fair', 'Good', 'Strong'];
const FIELD_ORDER = ['name', 'email', 'phone', 'dob', 'gender', 'track', 'password', 'confirm', 'bio', 'terms'];

// Defined OUTSIDE App so React keeps the same component between renders (inputs keep focus while typing)
function Field({ name, label, children, hint, error, valid }) {
  return (
    <div className={`field ${error ? 'invalid' : valid ? 'valid' : ''}`}>
      <label htmlFor={name}>{label} <span className="req">*</span></label>
      {children}
      {hint && !error && <small className="hint">{hint}</small>}
      {error && <small className="error" role="alert">⚠ {error}</small>}
    </div>
  );
}

export default function App() {
  const [values, setValues] = useState(INITIAL);
  const [touched, setTouched] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [showPw, setShowPw] = useState(false);
  const [done, setDone] = useState(null);

  // Validation runs on every render from the current values (derived state)
  const errors = useMemo(() => validateAll(values), [values]);
  const isValid = Object.keys(errors).length === 0;
  const strength = passwordStrength(values.password);
  const today = new Date().toISOString().split('T')[0];

  const show = (f) => (touched[f] || submitted) && errors[f];
  const ok = (f) => touched[f] && !errors[f] && values[f] !== '' && values[f] !== false;

  const onChange = (e) => {
    const { name, type, value, checked } = e.target;
    setValues((v) => ({ ...v, [name]: type === 'checkbox' ? checked : value }));
    if (type === 'checkbox' || type === 'radio') setTouched((t) => ({ ...t, [name]: true }));
  };
  const onBlur = (e) => setTouched((t) => ({ ...t, [e.target.name]: true }));

  const onSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
    if (!isValid) {
      const first = FIELD_ORDER.find((f) => errors[f]);
      const el = document.querySelector(`[name="${first}"]`);
      if (el) el.focus();
      return;
    }
    setDone({ ref: 'JU-' + Math.floor(10000 + Math.random() * 90000), ...values, age: calcAge(values.dob) });
  };

  const reset = () => { setValues(INITIAL); setTouched({}); setSubmitted(false); setDone(null); setShowPw(false); };



  return (
    <>
      <header className="top"><div className="logo">J</div><span>Join<b>Up</b></span></header>
      <main className="layout">
        <section className="intro">
          <span className="pill">● REACTJS CLIENT-SIDE VALIDATION</span>
          <h1>Instant, Smart <mark>Client-Side</mark> Validation.</h1>
          <p>A registration form built with React hooks. Every field is checked in the browser while you type, so mistakes are caught before anything is submitted.</p>
          <div className="card rules">
            <h3>Validation Rules</h3>
            <ul>
              <li><em>Name</em> 2–50 letters, spaces, - and '</li>
              <li><em>Email</em> Valid format, e.g. name@domain.com</li>
              <li><em>Mobile</em> 10 digits starting 6–9, optional +91</li>
              <li><em>DOB</em> Not in future • Age 16 or above</li>
              <li><em>Password</em> 8+ chars, upper, lower, number, symbol</li>
              <li><em>Confirm</em> Must match password</li>
              <li><em>About</em> 10 to 200 characters</li>
            </ul>
          </div>
        </section>

        <form className="card form" onSubmit={onSubmit} noValidate>
          <h2>Create your account</h2>
          <p className="sub">Fields marked * are required.</p>

          <Field name="name" label="Full Name" error={show('name')} valid={ok('name')}>
            <input id="name" name="name" value={values.name} onChange={onChange} onBlur={onBlur} placeholder="e.g. Riya Sharma" autoComplete="off" />
          </Field>
          <Field name="email" label="Email Address" error={show('email')} valid={ok('email')}>
            <input id="email" name="email" type="email" value={values.email} onChange={onChange} onBlur={onBlur} placeholder="e.g. riya.sharma@example.com" autoComplete="off" />
          </Field>
          <div className="row">
            <Field name="phone" label="Mobile Number" error={show('phone')} valid={ok('phone')}>
              <input id="phone" name="phone" value={values.phone} onChange={onChange} onBlur={onBlur} placeholder="e.g. 9876543210" autoComplete="off" />
            </Field>
            <Field name="dob" label="Date of Birth" error={show('dob')} valid={ok('dob')}>
              <input id="dob" name="dob" type="date" max={today} value={values.dob} onChange={onChange} onBlur={onBlur} />
            </Field>
          </div>
          <div className="row">
            <Field name="gender" label="Gender" error={show('gender')} valid={ok('gender')}>
              <div className="radios" onBlur={() => setTouched((t) => ({ ...t, gender: true }))}>
                {['Male', 'Female', 'Other'].map((g) => (
                  <label key={g} className="radio"><input type="radio" name="gender" value={g} checked={values.gender === g} onChange={onChange} /> {g}</label>
                ))}
              </div>
            </Field>
            <Field name="track" label="Workshop Track" error={show('track')} valid={ok('track')}>
              <select id="track" name="track" value={values.track} onChange={onChange} onBlur={onBlur}>
                <option value="">-- Select a Track --</option>
                {TRACKS.map((t) => <option key={t}>{t}</option>)}
              </select>
            </Field>
          </div>
          <Field name="password" label="Password" error={show('password')} valid={ok('password')}>
            <div className="pw">
              <input id="password" name="password" type={showPw ? 'text' : 'password'} value={values.password} onChange={onChange} onBlur={onBlur} placeholder="Create a strong password" autoComplete="new-password" />
              <button type="button" className="eye" onClick={() => setShowPw((s) => !s)}>{showPw ? 'Hide' : 'Show'}</button>
            </div>
            {values.password && (
              <div className="meter" aria-live="polite">
                <div className="bars">{[1, 2, 3, 4].map((i) => <span key={i} className={i <= strength ? `on s${strength}` : ''} />)}</div>
                <small className={`lvl s${strength}`}>{STRENGTH[strength]}</small>
              </div>
            )}
          </Field>
          <Field name="confirm" label="Confirm Password" error={show('confirm')} valid={ok('confirm')}>
            <input id="confirm" name="confirm" type={showPw ? 'text' : 'password'} value={values.confirm} onChange={onChange} onBlur={onBlur} placeholder="Re-enter your password" autoComplete="new-password" />
          </Field>
          <Field name="bio" label="Why do you want to join?" error={show('bio')} valid={ok('bio')}>
            <textarea id="bio" name="bio" rows="3" value={values.bio} onChange={onChange} onBlur={onBlur} placeholder="Type your reason here... (minimum 10 characters)" />
            <span className={`count ${values.bio.trim().length > 200 ? 'over' : ''}`}>{values.bio.trim().length} / 200 chars</span>
          </Field>
          <Field name="terms" label="Terms" error={show('terms')} valid={ok('terms')}>
            <label className="check"><input type="checkbox" name="terms" checked={values.terms} onChange={onChange} /> I accept the terms and conditions</label>
          </Field>

          <div className="actions">
            <button type="button" className="btn ghost" onClick={reset}>Clear Form</button>
            <button type="submit" className="btn primary">Register Now</button>
          </div>
          {submitted && !isValid && <p className="banner">Please fix the highlighted errors ({Object.keys(errors).length} remaining).</p>}
        </form>
      </main>

      {done && (
        <div className="overlay" role="dialog" aria-modal="true">
          <div className="modal">
            <div className="tick">✓</div>
            <span className="pill">CLIENT VALIDATION PASSED</span>
            <h3>Registration Confirmed!</h3>
            <p>Your details passed every React validation rule in the browser.</p>
            <dl>
              <div className="refrow"><dt>REGISTRATION REFERENCE</dt><dd className="ref">{done.ref}</dd></div>
              <div><dt>Name:</dt><dd>{done.name.trim()}</dd></div>
              <div><dt>Email:</dt><dd>{done.email.trim()}</dd></div>
              <div><dt>Track:</dt><dd>{done.track}</dd></div>
              <div><dt>Age:</dt><dd>{done.age} years</dd></div>
            </dl>
            <button className="btn primary full" onClick={reset}>Register Another Person</button>
          </div>
        </div>
      )}
    </>
  );
}
