// Pure validation functions (no React) so they are easy to unit-test.
// Each returns an error message string, or '' when the value is valid.

export const TRACKS = ['Web Development', 'Data Science', 'Cloud Computing', 'Cyber Security', 'AI & Machine Learning'];

export const validateName = (v) => {
  const s = v.trim();
  if (!s) return 'Full name is required.';
  if (s.length < 2) return 'Name must be at least 2 characters.';
  if (s.length > 50) return 'Name must not exceed 50 characters.';
  if (!/^[A-Za-z][A-Za-z\s'-]*$/.test(s)) return 'Name can only contain letters, spaces, hyphens and apostrophes.';
  return '';
};

export const validateEmail = (v) => {
  const s = v.trim();
  if (!s) return 'Email address is required.';
  if (!/^[^\s@]+@[^\s@]+\.[A-Za-z]{2,}$/.test(s)) return 'Enter a valid email address (e.g. you@example.com).';
  return '';
};

export const validatePhone = (v) => {
  const s = v.replace(/[\s-]/g, '');
  if (!s) return 'Mobile number is required.';
  if (!/^(\+91)?[6-9]\d{9}$/.test(s)) return 'Enter a valid 10-digit Indian mobile number starting with 6-9.';
  return '';
};

export const calcAge = (dob, today = new Date()) => {
  const d = new Date(dob);
  let age = today.getFullYear() - d.getFullYear();
  const m = today.getMonth() - d.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < d.getDate())) age--;
  return age;
};

export const validateDob = (v, today = new Date()) => {
  if (!v) return 'Date of birth is required.';
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return 'Enter a valid date.';
  if (d > today) return 'Date of birth cannot be in the future.';
  if (calcAge(v, today) < 16) return 'You must be at least 16 years old to register.';
  return '';
};

export const validateTrack = (v) => (!v ? 'Please select a track.' : TRACKS.includes(v) ? '' : 'Invalid track selected.');

export const validateGender = (v) => (v ? '' : 'Please select a gender option.');

export const validatePassword = (v) => {
  if (!v) return 'Password is required.';
  if (v.length < 8) return 'Password must be at least 8 characters.';
  if (!/[A-Z]/.test(v)) return 'Add at least one uppercase letter.';
  if (!/[a-z]/.test(v)) return 'Add at least one lowercase letter.';
  if (!/\d/.test(v)) return 'Add at least one number.';
  if (!/[^A-Za-z0-9]/.test(v)) return 'Add at least one special character (e.g. @ # $ !).';
  return '';
};

export const validateConfirm = (v, password) => {
  if (!v) return 'Please confirm your password.';
  if (v !== password) return 'Passwords do not match.';
  return '';
};

export const validateBio = (v) => {
  const s = v.trim();
  if (!s) return 'Please tell us why you want to join.';
  if (s.length < 10) return `Too short (${s.length} chars). Minimum 10 characters required.`;
  if (s.length > 200) return 'Maximum 200 characters allowed.';
  return '';
};

export const validateTerms = (v) => (v ? '' : 'You must accept the terms to continue.');

// 0 (empty) .. 4 (very strong)
export const passwordStrength = (pw) => {
  if (!pw) return 0;
  let score = 0;
  if (pw.length >= 8) score++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
  if (/\d/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  return score;
};

export const validateAll = (f) => {
  const errors = {
    name: validateName(f.name),
    email: validateEmail(f.email),
    phone: validatePhone(f.phone),
    dob: validateDob(f.dob),
    gender: validateGender(f.gender),
    track: validateTrack(f.track),
    password: validatePassword(f.password),
    confirm: validateConfirm(f.confirm, f.password),
    bio: validateBio(f.bio),
    terms: validateTerms(f.terms)
  };
  Object.keys(errors).forEach((k) => !errors[k] && delete errors[k]);
  return errors;
};
