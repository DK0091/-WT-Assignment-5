import test from 'node:test';
import assert from 'node:assert/strict';
import * as v from './validators.js';

test('name: valid and invalid cases', () => {
  assert.equal(v.validateName('Darshan Kale'), '');
  assert.equal(v.validateName("Mary-Anne O'Neil"), '');
  assert.notEqual(v.validateName(''), '');
  assert.notEqual(v.validateName('A'), '');
  assert.notEqual(v.validateName('Darshan99'), '');
});

test('email: valid and invalid cases', () => {
  assert.equal(v.validateEmail('darshan.kale@example.com'), '');
  assert.notEqual(v.validateEmail('darshan.kale.com'), '');
  assert.notEqual(v.validateEmail('a@b'), '');
  assert.notEqual(v.validateEmail(''), '');
});

test('phone: Indian mobile numbers', () => {
  assert.equal(v.validatePhone('9876543210'), '');
  assert.equal(v.validatePhone('+91 98765 43210'), '');
  assert.notEqual(v.validatePhone('12345'), '');
  assert.notEqual(v.validatePhone('5876543210'), '');
});

test('dob: future dates and under-age are rejected', () => {
  const today = new Date('2026-11-20');
  assert.equal(v.validateDob('2004-05-10', today), '');
  assert.notEqual(v.validateDob('2027-01-01', today), '');
  assert.notEqual(v.validateDob('2018-01-01', today), '');
  assert.notEqual(v.validateDob('', today), '');
});

test('password rules and strength meter', () => {
  assert.equal(v.validatePassword('Strong@123'), '');
  assert.notEqual(v.validatePassword('short'), '');
  assert.notEqual(v.validatePassword('alllowercase1!'), '');
  assert.notEqual(v.validatePassword('NoSpecial123'), '');
  assert.equal(v.passwordStrength(''), 0);
  assert.equal(v.passwordStrength('Strong@123'), 4);
});

test('confirm password must match', () => {
  assert.equal(v.validateConfirm('Strong@123', 'Strong@123'), '');
  assert.notEqual(v.validateConfirm('Other@123', 'Strong@123'), '');
});

test('validateAll returns no errors for a fully valid form', () => {
  const ok = { name: 'Darshan Kale', email: 'd@example.com', phone: '9876543210', dob: '2004-05-10', gender: 'Male',
    track: 'Web Development', password: 'Strong@123', confirm: 'Strong@123', bio: 'I want to learn React properly.', terms: true };
  assert.deepEqual(v.validateAll(ok), {});
  assert.ok(Object.keys(v.validateAll({ ...ok, email: 'bad', terms: false })).length === 2);
});
